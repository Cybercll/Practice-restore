Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   storyDatafile    usealloc
   storyDatafile    querymain
   Alice            querymain
   alloc            allocPtr  
   alloc            allocSP

Programs not listed above print output and do
not read any input

